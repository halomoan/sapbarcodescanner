import 'package:sqflite/sqflite.dart'; //sqflite package
import 'package:path_provider/path_provider.dart'; //path_provider package
import 'package:path/path.dart'; //used to join paths
import 'barcodeModel.dart'; //import model class
import 'dart:io';
import 'dart:async';

class DBHelper {
  DBHelper() {
    init();
  }

  Future<Database> init() async {
    Directory directory =
        await getApplicationDocumentsDirectory(); //returns a directory which stores permanent files
    final path = join(directory.path, "barcode.db"); //create path to database

    return await openDatabase(
        //open the database or create a database if there isn't any
        path,
        version: 2, onCreate: (Database db, int version) async {
      await db.execute("""
          CREATE TABLE barcode(
          barcodeno TEXT PRIMARY KEY,
          cocode TEXT,         
          maincode TEXT,
          subcode TEXT,           
          seq TEXT,
          desc TEXT,
          loc TEXT,
          tqty INTEGER,
          createdat INTEGER DEFAULT (cast(strftime('%s','now') as int)       
          )""");
    });
  }

  Future<int> add(BarcodeModel item) async {
    //returns number of items inserted as an integer
    final db = await init(); //open database
    return db.insert(
      "barcode", item.toMap(), //toMap() function from MemoModel
      conflictAlgorithm:
          ConflictAlgorithm.ignore, //ignores conflicts due to duplicate entries
    );
  }

  Future<List<BarcodeModel>> getBarcodes() async {
    //returns the barcodes as a list (array)

    final db = await init();
    final maps = await db
        .query("barcode"); //query all the rows in a table as an array of maps

    return List.generate(maps.length, (i) {
      //create a list of memos
      return BarcodeModel(
          id: maps[i]['id'],
          coCode: maps[i]['cocode'],
          barcodeNo: maps[i]['barcodeno'],
          mainCode: maps[i]['maincode'],
          subCode: maps[i]['subcode'],
          seq: maps[i]['seq'],
          desc: maps[i]['desc'],
          loc: maps[i]['loc'],
          tqty: maps[i]['tqty'],
          createdat: maps[i]['createdat']);
    });
  }

  Future<int> delete(int id) async {
    //returns number of items deleted
    final db = await init();

    int result = await db.delete("barcode", //table name
        where: "id = ?",
        whereArgs: [id] // use whereArgs to avoid SQL injection
        );

    return result;
  }

  Future<int> update(int id, BarcodeModel item) async {
    // returns the number of rows updated

    final db = await init();

    int result = await db
        .update("barcode", item.toMap(), where: "id = ?", whereArgs: [id]);
    return result;
  }

  Future close() async {
    final db = await init();
    db.close();
  }
}
