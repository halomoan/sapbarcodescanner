class BarcodeModel {
  int id = 0;
  String barcodeNo = "";
  String coCode = "";
  String mainCode = "";
  String subCode = "";
  String seq = "";
  String desc = "";
  String loc = "";
  int tqty = 0;
  int createdat = 0;

  BarcodeModel(
      {this.id,
      this.coCode,
      this.barcodeNo,
      this.mainCode,
      this.subCode,
      this.seq,
      this.desc,
      this.loc,
      this.tqty});

  Map<String, dynamic> toMap() {
    return <String, dynamic>{
      "id": id,
      "cocode": coCode,
      "barcodeno": barcodeNo,
      "maincode": mainCode,
      "subcode": subCode,
      "seq": seq,
      "desc": desc,
      "loc": loc,
      "tqty": tqty
    };
  }

  BarcodeModel.fromMap(Map<String, dynamic> map) {
    id = map['id'];
    coCode = map['cocode'];
    barcodeNo = map['barcodno'];
    mainCode = map['maincode'];
    subCode = map['subcode'];
    seq = map['seq'];
    desc = map['desc'];
    loc = map['loc'];
    tqty = map['tqty'];
  }
}
